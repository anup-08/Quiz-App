const questionArray = [
    {
        question : "1. What is the capital of France?",
        Option : [
            { text:"Berlin" , correct:false },
            { text:"Madrid", correct:false },
            { text:"Paris", correct:true },
            { text:"Rome", correct:false }
        ]
        
    },
    {
        question : "2. Which number is an even number?",
        Option : [
            { text:"3", correct:false },
            { text:"7", correct:false },
            { text:"9", correct:false },
            { text:"10", correct:true }
        ]        
    },
    {
        question : "3. What color do you get when you mix red and yellow?",
        Option : [
            { text:"Purple", correct:false },
            { text:"Green", correct:false },
            { text:"Orange", correct:true },
            { text:"Blue", correct:false }
        ]
       
    },
    {
        question : "4. Which planet is known as the Red Planet?",
        Option : [ 
            { text:"Earth", correct:false },
            { text:"Venus", correct:false },
            { text:"Jupiter", correct:false },
            { text:"Mars", correct:true }
        ]
        
    },
    {
        question : "5. Which animal is known as the King of the Jungle?",
        Option : [
            { text:"Elephant", correct:false },
            { text:"Lion", correct:true },
            { text:"Tiger", correct:false },
            { text:"Bear", correct:false }
        ]
    }
]

const questionContainer = document.querySelector("#question");
const buttonAnswer = document.querySelector(".ans");

const nextButton = document.querySelector(".next");

let currentIndex = 0;
let score = 0;

function startQuiz(){
    currentIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    showQuestion();
}

function showQuestion(){
    restart()
    const currentQuestion = questionArray[currentIndex];

    questionContainer.innerHTML = `<h4>${currentQuestion.question}</h4>`;

    currentQuestion.Option.forEach((options) =>{
        const btn = document.createElement('button')
        btn.innerHTML = options.text;
        btn.classList.add("button");
        btn.dataset.correct = options.correct;
        buttonAnswer.appendChild(btn);
    })
}

startQuiz();

function restart(){
    questionContainer.innerHTML = "";
    nextButton.style.display = 'none';
    while(buttonAnswer.firstChild){
        buttonAnswer.removeChild(buttonAnswer.firstChild)
    }
} 


function nextButn(){
    nextButton.style.display = "block"
    nextButton.style.background = "#7a9cc0"
    nextButton.style.color = "black"
}


document.addEventListener('click',(event)=>{

    if(event.target.classList.contains("button")){

        const clickedButton = event.target;

        if(clickedButton.dataset.correct == "true" ){
            clickedButton.classList.add("correctButton")
            score++;
        }
        else{
            clickedButton.classList.add("wrongButton")
            
        }
        Array.from(buttonAnswer.children).forEach((button) =>{
            if(button.dataset.correct === "true"){
                button.classList.add("correctButton")
            }
            button.disabled = true;
        });
        nextButn()
    } 
})

function handleQuestion(){
    currentIndex++;
    if( currentIndex < questionArray.length ){
        showQuestion()
    }
    else{
        showScore()
    }
}

function showScore(){
    restart();
    const displayScore = document.createElement("h3")
    displayScore.innerHTML = `Yah..! your total score is ${score}`
    buttonAnswer.appendChild(displayScore);
    
    nextButton.innerHTML = "Play Again"
    nextButn()
}

nextButton.addEventListener('click' , ()=>{
    if(currentIndex <  questionArray.length){
        handleQuestion()
    }else{
        startQuiz()
    }
})